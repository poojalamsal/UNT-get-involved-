// Homepage - Explore Clubs landing page
// Author: Ifunaya
// Displays club listings with navigation to Club Details

import Link from "next/link"
import Image from "next/image"
import { Header } from "@/components/header"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Users, ChevronRight } from "lucide-react"
import { mockClubs } from "@/lib/mock-data"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main>
        {/* Hero Section */}
        <section className="relative overflow-hidden bg-gradient-to-b from-primary/5 to-background py-16 sm:py-24">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h1 className="text-4xl font-bold tracking-tight text-foreground sm:text-5xl lg:text-6xl text-balance">
                Discover Your Campus Community
              </h1>
              <p className="mx-auto mt-6 max-w-2xl text-lg text-muted-foreground text-pretty">
                Join student organizations, attend events, and connect with peers who share your interests. 
                Find your place on campus today.
              </p>
              <div className="mt-8 flex flex-wrap justify-center gap-4">
                <Button size="lg" asChild>
                  <Link href="#clubs">Browse Clubs</Link>
                </Button>
                <Button variant="outline" size="lg">
                  How It Works
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="border-y border-border bg-muted/30 py-8">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-2 gap-8 md:grid-cols-4">
              <div className="text-center">
                <p className="text-3xl font-bold text-foreground">150+</p>
                <p className="text-sm text-muted-foreground">Active Clubs</p>
              </div>
              <div className="text-center">
                <p className="text-3xl font-bold text-foreground">5,000+</p>
                <p className="text-sm text-muted-foreground">Members</p>
              </div>
              <div className="text-center">
                <p className="text-3xl font-bold text-foreground">200+</p>
                <p className="text-sm text-muted-foreground">Events Monthly</p>
              </div>
              <div className="text-center">
                <p className="text-3xl font-bold text-foreground">15</p>
                <p className="text-sm text-muted-foreground">Categories</p>
              </div>
            </div>
          </div>
        </section>

        {/* Featured Clubs Section */}
        <section id="clubs" className="py-16">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-foreground sm:text-3xl">Featured Clubs</h2>
                <p className="mt-2 text-muted-foreground">Popular organizations looking for new members</p>
              </div>
              <Button variant="ghost" className="hidden sm:inline-flex">
                View All <ChevronRight className="ml-1 h-4 w-4" />
              </Button>
            </div>

            <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {mockClubs.map((club) => (
                <Link key={club.id} href={`/clubs/${club.id}`}>
                  <Card className="group h-full overflow-hidden transition-all hover:shadow-lg hover:border-primary/30">
                    {/* Club Cover Image */}
                    <div className="relative h-40 overflow-hidden">
                      <Image
                        src={club.coverImage}
                        alt={club.name}
                        fill
                        className="object-cover transition-transform group-hover:scale-105"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent" />
                      <div className="absolute bottom-3 left-3">
                        <Badge variant="secondary" className="text-xs">
                          {club.category}
                        </Badge>
                      </div>
                      {club.isRecruiting && (
                        <div className="absolute right-3 top-3">
                          <Badge className="bg-accent text-accent-foreground text-xs">
                            Recruiting
                          </Badge>
                        </div>
                      )}
                    </div>

                    <CardContent className="p-4">
                      <h3 className="font-semibold text-foreground group-hover:text-primary transition-colors">
                        {club.name}
                      </h3>
                      <p className="mt-2 text-sm text-muted-foreground line-clamp-2">
                        {club.description}
                      </p>
                    </CardContent>

                    <CardFooter className="flex items-center justify-between border-t border-border px-4 py-3">
                      <div className="flex items-center gap-1 text-sm text-muted-foreground">
                        <Users className="h-4 w-4" />
                        <span>{club.memberCount} members</span>
                      </div>
                      <span className="text-sm font-medium text-primary">
                        View Details
                      </span>
                    </CardFooter>
                  </Card>
                </Link>
              ))}
            </div>

            <div className="mt-8 text-center sm:hidden">
              <Button variant="outline">
                View All Clubs <ChevronRight className="ml-1 h-4 w-4" />
              </Button>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="bg-primary py-16">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-2xl font-bold text-primary-foreground sm:text-3xl text-balance">
              Ready to Get Involved?
            </h2>
            <p className="mx-auto mt-4 max-w-xl text-primary-foreground/80 text-pretty">
              Create an account to save clubs, RSVP to events, and join the campus community.
            </p>
            <div className="mt-8 flex flex-wrap justify-center gap-4">
              <Button variant="secondary" size="lg">
                Create Account
              </Button>
              <Button variant="outline" size="lg" className="bg-transparent text-primary-foreground border-primary-foreground/30 hover:bg-primary-foreground/10">
                Learn More
              </Button>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-border bg-background py-8">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col items-center justify-between gap-4 sm:flex-row">
            <p className="text-sm text-muted-foreground">
              CampusClubs - Built by Ifunaya for CS Junior Project
            </p>
            <div className="flex gap-4 text-sm text-muted-foreground">
              <a href="#" className="hover:text-foreground transition-colors">About</a>
              <a href="#" className="hover:text-foreground transition-colors">Privacy</a>
              <a href="#" className="hover:text-foreground transition-colors">Contact</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
