"use client"

// Header component for CampusClubs navigation
// Author: Ifunaya

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Search, Menu, X } from "lucide-react"
import { useState } from "react"

export function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary">
            <span className="text-lg font-bold text-primary-foreground">C</span>
          </div>
          <span className="text-xl font-semibold text-foreground">CampusClubs</span>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden items-center gap-6 md:flex">
          <Link 
            href="/" 
            className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
          >
            Explore
          </Link>
          <Link 
            href="/clubs/1" 
            className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
          >
            Club Details
          </Link>
          <Link 
            href="#" 
            className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
          >
            Events
          </Link>
          <Link 
            href="#" 
            className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
          >
            My Clubs
          </Link>
        </nav>

        {/* Search & Actions */}
        <div className="hidden items-center gap-4 md:flex">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input 
              type="search" 
              placeholder="Search clubs..." 
              className="w-64 pl-9"
            />
          </div>
          <Button variant="outline" size="sm">Sign In</Button>
          <Button size="sm">Join Now</Button>
        </div>

        {/* Mobile Menu Button */}
        <button
          type="button"
          className="inline-flex items-center justify-center rounded-md p-2 text-muted-foreground hover:bg-accent hover:text-foreground md:hidden"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          aria-label="Toggle menu"
        >
          {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="border-t border-border bg-background md:hidden">
          <div className="space-y-1 px-4 py-3">
            <div className="relative mb-3">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input 
                type="search" 
                placeholder="Search clubs..." 
                className="w-full pl-9"
              />
            </div>
            <Link 
              href="/" 
              className="block rounded-md px-3 py-2 text-base font-medium text-foreground hover:bg-accent"
            >
              Explore
            </Link>
            <Link 
              href="/clubs/1" 
              className="block rounded-md px-3 py-2 text-base font-medium text-foreground hover:bg-accent"
            >
              Club Details
            </Link>
            <Link 
              href="#" 
              className="block rounded-md px-3 py-2 text-base font-medium text-foreground hover:bg-accent"
            >
              Events
            </Link>
            <Link 
              href="#" 
              className="block rounded-md px-3 py-2 text-base font-medium text-foreground hover:bg-accent"
            >
              My Clubs
            </Link>
            <div className="flex gap-2 pt-3">
              <Button variant="outline" size="sm" className="flex-1">Sign In</Button>
              <Button size="sm" className="flex-1">Join Now</Button>
            </div>
          </div>
        </div>
      )}
    </header>
  )
}
