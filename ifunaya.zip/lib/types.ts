// Club-related types for the CampusClubs application
// Author: Ifunaya

export interface ClubEvent {
  id: string
  title: string
  date: string
  time: string
  location: string
  description: string
}

export interface ClubMember {
  id: string
  name: string
  role: string
  avatar?: string
  year: string
}

export interface Club {
  id: string
  name: string
  description: string
  longDescription: string
  category: string
  memberCount: number
  meetingSchedule: string
  location: string
  email: string
  website?: string
  socialMedia?: {
    instagram?: string
    twitter?: string
    discord?: string
  }
  coverImage: string
  logo: string
  tags: string[]
  isRecruiting: boolean
  events: ClubEvent[]
  officers: ClubMember[]
  requirements?: string[]
  dues?: string
}

export type ClubCategory = 
  | "Academic"
  | "Arts & Culture"
  | "Sports & Recreation"
  | "Technology"
  | "Community Service"
  | "Professional"
  | "Social"
  | "Religious"
  | "Political"
  | "Media"
